June 13, 2015 : 

Rapid clicker left clicks. 

Specify the delay between clicks in milliseconds (1000ms = 1s), the value cannot be negative.
Be careful with low values, especially 0, lag will surely ensue.


Keys: 

ESC       : exit the application.
LEFT CTRL : toggle clicking.

The window does not need to be in focus to use these keys.